# 烬渊 — Equipment & Progression Compendium

## Armor Categories

| Weight Class | Chinese | Physical Reduction | Elemental Reduction | Stamina Penalty | Mobility |
|-------------|---------|-------------------|--------------------|--------------------|----------|
| Light | 轻甲 | 5-12% | 10-25% | None | Fast roll |
| Medium | 中甲 | 12-20% | 5-15% | -5% stamina regen | Mid roll |
| Heavy | 重甲 | 20-35% | 3-8% | -12% stamina regen | Fat roll |

---

## Chapter 1 Equipment

| Item | Slot | Weight | Physical | Elemental | Special Effect | Location |
|------|------|--------|----------|-----------|----------------|----------|
| 破旧护符 (Worn Talisman) | Accessory | — | — | — | +5 max HP | 1-1 |
| 镜影斗篷 (Mirror-Shade Cloak) | Chest | Light | 6% | 12% | +3% dodge invulnerability window | 1-3 |
| 炼丹师护腕 (Alchemist's Bracers) | Arms | Light | 3% | 8% | +5 max Focus | 1-4 |
| 守炉人面具 (Furnace-Keeper's Mask) | Head | Medium | 8% | 5% | +10% Ember gain | 1-5 boss |
| 羽冠 (Feather Crown) | Head | Light | 3% | 5% | +2 Focus | 神射手 start |
| 战鬼面 (War Demon Mask) | Head | Medium | 10% | 2% | +3 Rage on kill | 狂战士 start |
| 道士冠 (Daoist Crown) | Head | Light | 4% | 10% | +5 Focus | 玄法师 start |
| 僧冠 (Monastic Crown) | Head | Light | 3% | 8% | +5 Focus | 祝祷师 start |
| 轻皮甲 (Light Leather Armor) | Chest | Light | 8% | 5% | — | 神射手 start |
| 兽皮战甲 (Beast-Hide Battle Armor) | Chest | Medium | 14% | 3% | — | 狂战士 start |
| 玄色道袍 (Mystic Daoist Robe) | Chest | Light | 5% | 15% | — | 玄法师 start |
| 袈裟 (Kasaya Robe) | Chest | Light | 8% | 20% dark | — | 祝祷师 start |

---

## Chapter 2 Equipment

| Item | Slot | Weight | Physical | Elemental | Special Effect | Location |
|------|------|--------|----------|-----------|----------------|----------|
| 铁啸战甲 (Iron Howl Battle Armor) | Chest | Heavy | 28% | 5% | -10% damage from 失魂-type enemies | 2-3 |
| 烽火头盔 (Beacon Helmet) | Head | Medium | 12% | 8% fire | Fire resistance +15% | 2-4 |
| 将军肩甲 (General's Pauldrons) | Shoulders | Heavy | 18% | 3% | +8% poise (stagger resistance) | 2-5 |
| 铁心护手 (Iron Heart Gauntlets) | Arms | Heavy | 15% | 2% | +5% hyper armor duration | 2-3 |
| 战烬护符 (War Ember Talisman) | Accessory | — | — | — | +15% damage when below 30% HP | 2-5 |
| 督军腰带 (Warlord's Belt) | Legs | Heavy | 16% | 2% | +8 max stamina | 2-2 |

---

## Chapter 3 Equipment

| Item | Slot | Weight | Physical | Elemental | Special Effect | Location |
|------|------|--------|----------|-----------|----------------|----------|
| 红盖头 (Red Bridal Veil) | Head | Light | 2% | 12% | Immune to Charm status | 3-3 |
| 玉鳞袍 (Jade Scale Robe) | Chest | Medium | 14% | 18% wood | +10% healing received | 3-5 |
| 镜花簪 (Mirror Flower Hairpin) | Accessory | — | — | — | After dodging, leave a 1s afterimage | 3-4 |
| 前世护符 (Past-Life Talisman) | Accessory | — | — | — | On death, retain 30% of carried Embers | 3-2 |
| 翠微玉佩 (Jade Forest Pendant) | Accessory | — | — | — | +8% movement speed in forest/grass areas | 3-1 |
| 狐裘披风 (Fox Fur Cape) | Chest | Light | 6% | 15% fire | +10% Focus regen at night/in dark areas | 3-3 |

---

## Chapter 4 Equipment

| Item | Slot | Weight | Physical | Elemental | Special Effect | Location |
|------|------|--------|----------|-----------|----------------|----------|
| 登仙残袍 (Ascension-Incomplete Robe) | Chest | Light | 5% | 20% light | Brief anti-gravity after taking a hit (10s cooldown) | 4-5 boss |
| 云锦天衣 (Cloud-Brocade Heavenly Garment) | Chest | Light | 7% | 18% | +15% Focus regen while airborne | 4-2 |
| 执念护符 (Obsession Talisman) | Accessory | — | — | — | Spells cost -10% Focus but +15% cast time | 4-5 boss |
| 登天符 (Heaven-Ascending Talisman) | Accessory | — | — | — | +20% jump height, slow fall enabled | 4-1 |
| 云霄冠冕 (Cloud Zenith Crown) | Head | Light | 3% | 15% | +10% spell range | 4-3 |
| 堕仙护腕 (Fallen Immortal Bracers) | Arms | Medium | 8% | 10% | Spells steal 3% of damage dealt as HP | 4-4 |

---

## Chapter 5 Equipment

| Item | Slot | Weight | Physical | Elemental | Special Effect | Location |
|------|------|--------|----------|-----------|----------------|----------|
| 铸魂者长袍 (Soul-Forger's Robe) | Chest | Light | 10% | 25% | +20% all elemental resistances for 8s after casting | 5-4 |
| 烬渊王冠 (Ember Abyss Crown) | Head | Medium | 12% | 15% | +1 Talent Point while equipped | 5-5 |
| 倒悬护符 (Inversion Talisman) | Accessory | — | — | — | Gravity effects reduced by 50% | 5-2 |
| 轮回之石 (Samsara Stone) | Accessory | — | — | — | In 5-3, shows the source chapter flag and reveals the accept/regret consequences before confirmation | 5-3 |
| 九铸魂者之证 (Nine Fallen Forgers' Seal) | Accessory | — | — | — | +5% all stats per fallen Soul-Forger communed (max +15%) | 5-4 |
| 终末步伐 (Eschaton Greaves) | Legs | Heavy | 18% | 8% | Walking through damaging terrain negates its effect for 2s | 5-2 |

---

## Chapter-Unique Consumables

| Item | Chapter | Effect | Max Carry |
|------|---------|--------|-----------|
| 回神香 (Spirit-Recalling Incense) | 1 | Restore 30 Focus | 5 |
| 炽火丸 (Blazing Fire Pill) | 1 | +15% damage for 60s | 3 |
| 烽火号角 (Beacon Horn) | 2 | Summon phantom ally for 60s | 2 |
| 止血散 (Bleed-Stopping Powder) | 2 | Cure bleed, +10 HP | 5 |
| 醒神丹 (Spirit-Awakening Pill) | 3 | Cure confusion/charm, +15 Focus | 5 |
| 幻影尘 (Illusion Dust) | 3 | Invisible for 10s (breaks on attack) | 3 |
| 不朽丹 (Immortality Pill) | 4 | Full heal + 15s invincibility | 1 |
| 聚灵丹 (Spirit-Gathering Pill) | 4 | +50 Focus instantly | 3 |
| 终末余烬 (Final Cinder) | 5 | Full HP/Focus restore + 30s infinite stamina | 1 |

---

## Progression Economy

### Ember Acquisition Rates

| Source | Embers | Notes |
|--------|--------|-------|
| Basic enemy | 12-30 | Scales with chapter |
| Elite enemy | 40-95 | Scales with difficulty |
| Sub-boss | 120-200 | |
| Chapter boss | 350-1000 | |
| Hidden pickup | 25-100 | Fixed per location |
| Lost Soul recovery | Varies | Recovers previously dropped Embers |

### Total Embers Per Chapter (Estimated)

| Chapter | Enemies | Boss | Pickups | Approximate Total |
|---------|---------|------|---------|-------------------|
| 1 | ~200 | 350 | ~150 | ~700 |
| 2 | ~400 | 680 | ~250 | ~1,330 |
| 3 | ~500 | 520 | ~300 | ~1,320 |
| 4 | ~550 | 750 | ~350 | ~1,650 |
| 5 | ~400 | 1000 | ~400 | ~1,800 |
| **Game Total** | | | | **~6,800** |

### Upgrade Cost Summary

| System | Total Cost to Max (One Path) |
|--------|------------------------------|
| Cultivation (Level 60 soft cap) | ~183,000 Embers |
| Meridians (all 8 at Lv.5) | 烬递增成本代偿（每脉 5 级合计 2,320 烬；设计材料灵气结晶/纯阳石/龙脉精髓待掉落系统落地后替换）(L-09) |
| Soul Vessels (all 5 at +5) | 单轨 `vessel_level` +1..+5，共 7,700 Embers（实现为单轨；设计 5 魂器各 +5 待扩展）(L-15) |
| One Weapon (+10) | 铁心锻造走烬：+1..+10 各阶 120…2,600，共 9,290 Embers (L-15) |
| Talent Points | From levels (free), not purchased |

### NG+ Economy
- Ember drops increased by 50%
- Upgrade material drops increased by 30%
- New "Ancient Ember" currency for NG+ exclusive items
- Boss Soul Vessels can be reinforced to +6 (NG+) and +7 (NG++)
