# Elite Name Alignment — 精英怪命名对齐清单

**Status:** 🔵 部分完成（Ch.1 精英①已对齐 ✅；Ch.3 精英①归 wave2 九尾任务 ⏳；其余 ❌ 待对齐）
**Owner:** L-22（P1-4）
**Updated:** 2026-08-11
**Authority:** [chapters/01-spirit-awakening/chapter-supplement.md](../chapters/01-spirit-awakening/chapter-supplement.md) · [chapters/02-blood-iron/chapter-supplement.md](../chapters/02-blood-iron/chapter-supplement.md) · [chapters/03-jade-veil/chapter-supplement.md](../chapters/03-jade-veil/chapter-supplement.md) · [chapters/04-celestial-fall/chapter-supplement.md](../chapters/04-celestial-fall/chapter-supplement.md) · [chapters/05-throne-of-ashes/chapter-supplement.md](../chapters/05-throne-of-ashes/chapter-supplement.md) · [bestiary/enemies-master.md](../bestiary/enemies-master.md) · [bestiary/bosses-master.md](../bestiary/bosses-master.md)
**Design name authority:** 设计精英名册以各章 `chapter-supplement.md`「👹 精英怪」小节为准；`bestiary/` 仅列普通敌人与 Boss，不含精英 display_name，故不作对照源。

---

## 目标

让代码精英 `display_name`（`game/scripts/data/chapter_*_content.gd` 的 `elites()`）与设计名册对齐，并保留 bilingual（英文/中文）格式。**只改 `display_name` 文案，不改 `id`**（id 为内部键，多处 spawn/掉落按 id 引用，改名会破坏引用链）。

---

## 本次改动（✅ DONE）

| 文件 | 位置 | 旧名 | 新名（设计值） |
|------|------|------|------|
| `game/scripts/data/chapter_1_content.gd` | `elites()` 第 1 条（`elite_bronze_mirror_keeper`） | `Bronze Mirror Keeper / 铜镜守护者` | `Formation-Guarding Stone Sentinel / 守阵石卫` |

- 设计出处：`docs/chapters/01-spirit-awakening/chapter-supplement.md:51`「精英怪 1: 守阵石卫 (Formation-Guarding Stone Sentinel)」。
- 英文/中文均改为设计值；id `elite_bronze_mirror_keeper` 保持不变。
- 静态 grep 复核：`game/scripts/data/chapter_1_content.gd` 已无「铜镜守护者 / Bronze Mirror Keeper」。
- 仓库内其余对旧名的引用：仅 `docs/tasks/content-gap-backlog.md:57`（L-22 待办条目原文示例，属文档，不动）。

---

## 全量对照（代码 15 精英 vs 设计名册）

### 第一章 灵墟·觉醒

| Code id | Code display_name（现状） | Code 出现位 | 设计对应名 | 设计出现位 | 状态 |
|---------|---------------------------|-------------|-----------|-----------|------|
| `elite_bronze_mirror_keeper` | **Formation-Guarding Stone Sentinel / 守阵石卫** | level_01_03 | 守阵石卫 (Formation-Guarding Stone Sentinel) | 1-2 守门廊 隐藏侧室 | ✅ **DONE（本次）** |
| `elite_elixir_golem` | Elixir Golem / 丹药魔像 | level_01_04 | 炼丹痴魂 (Alchemy-Obsessed Spirit) | 1-4 炼丹房遗迹 | ❌ MISMATCH（按出现位 1-4 对应成立，名字待改） |

### 第二章 血铁·战歌

设计名册：炉暴刑具 (Forge-Rage Engine)、双生烽火守将 (Twin Beacon Generals)、贪噬军需官 (Gluttonous Quartermaster)。

| Code id | Code display_name（现状） | Code 出现位 | 设计对应名（按出现位推定） | 设计出现位 | 状态 |
|---------|---------------------------|-------------|---------------------------|-----------|------|
| `elite_torture_master` | Torture Master / 刑讯官 | level_02_03 | 炉暴刑具 (Forge-Rage Engine) | 2-3 俘虏营 锻造大厅 | ❌ MISMATCH（位置 2-3 吻合，名字待改） |
| `elite_beacon_lord` | Beacon Lord / 烽火将 | level_02_04 | 双生烽火守将 (Twin Beacon Generals) | 2-4 烽火台 塔顶 | ❌ MISMATCH（位置 2-4 吻合，名字待改） |
| `elite_siege_commander` | Siege Commander / 攻城校尉 | level_02_02 | 贪噬军需官 (Gluttonous Quartermaster) | 2-5 将军营帐 军需仓库 | ❌ MISMATCH（**名册错位**：代码把该精英放在 2-2，设计在 2-5；代码 2-2 无设计对应位） |

### 第三章 玉障·迷心

设计名册：千年树魂 (Thousand-Year Tree Spirit)、镜湖织梦者 (Mirror Lake Dream-Weaver)、迷宫诗人 (Maze Poet) + 支线精英 贪烬鬼。

| Code id | Code display_name（现状） | Code 出现位 | 设计对应名（按任务/位置推定） | 设计出现位 | 状态 |
|---------|---------------------------|-------------|------------------------------|-----------|------|
| `elite_memory_eater` | Memory Eater / 噬忆者 | level_03_02 | 千年树魂 (Thousand-Year Tree Spirit) | 3-1 翠微林入口 | ⏳ **PENDING（归 wave2 九尾任务；`game_world.gd:626` 注释「精英·噬忆者」需同步）** |
| `elite_reflection_lord` | Reflection Lord / 镜像主 | level_03_04 | 镜湖织梦者 (Mirror Lake Dream-Weaver) | 3-4 镜花水月亭 湖心亭 | ❌ MISMATCH（位置 3-4 吻合，名字待改） |
| `elite_fox_bride` | Fox Bride / 狐嫁娘 | level_03_03 | 迷宫诗人 (Maze Poet) | 3-5 九尾迷宫 中心喷泉 | ❌ MISMATCH（名册错位，待改） |
| `elite_ember_greed_ghost` | Ember-Greedy Ghost / 贪烬鬼 | level_03_04 | 贪烬鬼（证伪线精英） | 3-4（桥头供茶支线） | ✓ ALIGNED（中文一致；英文 Ember-Greedy Ghost 为代码拟定） |

### 第四章 天崩·陨落

设计名册：云桥守将 (Cloud Bridge Guardian)、经文守卫 (Scripture Guardian)、坠天工匠 (Falling Sky Artisan)。

| Code id | Code display_name（现状） | Code 出现位 | 设计对应名（按出现位推定） | 设计出现位 | 状态 |
|---------|---------------------------|-------------|---------------------------|-----------|------|
| `elite_celestial_swordsman` | Celestial Swordsman / 天剑士 | level_04_01 | 云桥守将 (Cloud Bridge Guardian) | 4-1 登天梯 最大漂浮平台 | ❌ MISMATCH（位置 4-1 吻合，名字待改） |
| `elite_scripture_keeper` | Scripture Keeper / 藏经主 | level_04_03 | 经文守卫 (Scripture Guardian) | 4-3 藏经阁 禁书区 | ❌ MISMATCH（位置 4-3 吻合；英文 Keeper/Guardian 近似但中文 藏经主/经文守卫 不同） |
| `elite_alchemy_master` | Alchemy Master / 炼丹宗师 | level_04_02 | 坠天工匠 (Falling Sky Artisan) | 4-2 炼丹云台 崩塌边缘 | ❌ MISMATCH（位置 4-2 吻合，名字待改） |

### 第五章 烬座·归墟

设计名册：逆熵化身 (Avatar of Anti-Entropy)、可能性之海 (Sea of Possibilities)、最后的烛阴侍者 (The Last Torch-Servant)。

| Code id | Code display_name（现状） | Code 出现位 | 设计对应名（按出现位推定） | 设计出现位 | 状态 |
|---------|---------------------------|-------------|---------------------------|-----------|------|
| `elite_gravity_twister` | Gravity Twister / 重力扭曲者 | level_05_02 | 逆熵化身 (Avatar of Anti-Entropy) | 5-2 倒悬殿 最扭曲区 | ❌ MISMATCH（位置 5-2 吻合，名字待改） |
| `elite_soul_forger_echo` | Soul-Forger Echo / 铸魂者回响 | level_05_04 | 最后的烛阴侍者 (The Last Torch-Servant) | 5-4 九铸魂者之墓 大门前 | ❌ MISMATCH（位置 5-4 吻合，名字待改） |
| `elite_void_sentinel` | Void Sentinel / 虚空守卫 | level_05_01 | 可能性之海 (Sea of Possibilities) | 5-3 轮回歧路 交汇节点 | ❌ MISMATCH（名册错位：代码放 5-1，设计在 5-3；剩余唯一对应） |

---

## 结论与待办

1. ✅ **已对齐（本次）：** Ch1 `elite_bronze_mirror_keeper` → `Formation-Guarding Stone Sentinel / 守阵石卫`。
2. ⏳ **PENDING（wave2 九尾任务）：** Ch3 `elite_memory_eater` → `Thousand-Year Tree Spirit / 千年树魂`；同步更新 `game_world.gd:626` 注释「精英·噬忆者」。
3. ❌ **其余 11 个代码精英 `display_name` 均与设计名册不一致**，共三类：
   - **纯改名（位置吻合，仅文案不同）：** Ch1 `elixir_golem`、Ch2 `torture_master`/`beacon_lord`、Ch3 `reflection_lord`、Ch4 全部 3 个、Ch5 `gravity_twister`/`soul_forger_echo`（计 9 个）。
   - **名册错位（位置也不同）：** Ch2 `siege_commander`（2-2 vs 设计 2-5）、Ch3 `fox_bride`（3-3 vs 设计 3-5）、Ch5 `void_sentinel`（5-1 vs 设计 5-3）（计 3 个）。
   - **已一致：** Ch3 `ember_greed_ghost`（贪烬鬼）。
4. **名册结构差异（非命名问题，供各章负责人知悉）：** 第二章代码在 level_02_02 有一个「攻城校尉」而设计名册无 2-2 精英；设计 2-5「贪噬军需官」代码未落在 2-5。第三章代码 `fox_bride`（狐嫁娘）在 3-3 而设计 3-3 无精英（3-3 狐嫁道为支线演出区）。是否需要按设计移动出现位，由对应章节任务决定。

## 风险与约束

- **id 不可改**：`elite_*` 为 spawn/掉落/存档引用键，改名需与 `game_world.gd` 等生成层联动，超出 L-22 命名对齐范围。
- **只改文案不跑 Godot**：本任务为静态文本对齐 + 文档，按约定不运行引擎；`display_name` 为纯展示字符串，无执行语义。
- **双语格式**：沿用 `"English / 中文"`（斜杠 + 空格）约定，与文件内其他条目一致。
